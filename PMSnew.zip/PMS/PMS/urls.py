"""PMS URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from PMSApp.views import *
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.views.generic import TemplateView

from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',index,name="index"),
	path('index/',index,name="index"),
    path('login/',login,name="login"),
    path('searchlogin/',searchlogin,name="searchlogin"),
    path('adminHome/',adminHome,name="adminHome"),
    path('store/',store,name="store"),
    path('StoreAct/',StoreAct,name="StoreAct"),
    path('delStore/',delStore,name="delStore"),
    path('supplier/',supplier,name="supplier"),
    path('supplierAct/',supplierAct,name="supplierAct"),
    path('delSupplier/',delSupplier,name="delSupplier"),
    path('storeHome/',storeHome,name="storeHome"),
    path('product/',product,name="product"),
    path('purchase/',purchase,name="purchase"),
    path('catload/',catload,name="catload"),
    path('cataction/',cataction,name="cataction"),
    path('viewcat/',viewcat,name="viewcat"),    
    path('subcatload/',subcatload,name="subcatload"),
    path('subcataction/',subcataction,name="subcataction"),
    path('viewsubcat/',viewsubcat,name="viewsubcat"),
    path('delcat/',delcat,name="delcat"),
    path('productaction/',productaction,name="productaction"),
    path('vendor/',vendor,name="vendor"),
    path('vendoraction/',vendoraction,name="vendoraction"),
    path('purchaseaction/',purchaseaction,name="purchaseaction"),
    path('purchasereq/',purchasereq,name="purchasereq"),
    path('delp/',delp,name="delp"),
    path('delr/',delr,name="delr"),
    path('stock/',stock,name="stock"),
    path('delstock/',delstock,name="delstock"),
    path('purchasentry/',purchasentry,name="purchasentry"),
    path('purchaseact/',purchaseact,name="purchaseact"),
    path('purchildaction/',purchildaction,name="purchildaction"),
    path('pchild/',pchild,name="pchild"),
    path('delpchild/',delpchild,name="delpchild"),
    path('report/',report,name="report"),
    path('reportaction/',reportaction,name="reportaction"),
    
    
    
     
     

   



]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns+=staticfiles_urlpatterns()
if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
urlpatterns+=static(settings.MEDIA_URL,document_root=settings.STATIC_ROOT)
urlpatterns+=staticfiles_urlpatterns()