from django.apps import AppConfig


class PmsappConfig(AppConfig):
    name = 'PMSApp'
