from django import forms
from PMSApp.models import imodel

class iform(forms.Form):
    icode=forms.CharField(max_length=100)
    iname=forms.CharField(max_length=100)
    cat=forms.CharField(max_length=100)
    sub=forms.CharField(max_length=100)
    desp=forms.CharField(max_length=100)
    mrp=forms.CharField(max_length=100)
    qty=forms.CharField(max_length=100)
    img=forms.FileField()
    class Meta:
        model=imodel
        fields=['icode','iname','catid','subid','desp','mrp','qty','img']