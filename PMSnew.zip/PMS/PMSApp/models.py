from django.db import models

# Create your models here.
class imodel(models.Model):
    icode=models.CharField(max_length=100)
    iname=models.CharField(max_length=100)
    catid=models.CharField(max_length=100)
    subid=models.CharField(max_length=100)
    desp=models.CharField(max_length=100)
    mrp=models.CharField(max_length=100)
    qty=models.CharField(max_length=100)
    img=models.FileField(upload_to='img')
    class Meta:
        db_table="item"



