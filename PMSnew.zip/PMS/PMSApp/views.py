from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import HttpResponseRedirect,redirect
from django.db import connection
from datetime import *
import datetime
from PMSApp.forms import iform
from PMSApp.models import imodel

today_date = datetime.date.today()
today = today_date.strftime("%y-%m-%d")

def index(request):
	return render(request,'index.html')
def login(request):
	return render(request,'login.html')
# def searchlogin(request):
#     cursor=connection.cursor()
#     p=request.POST['uname']
#     q=request.POST['upass']
#     sql2="select * from login where uname='%s' and upass='%s'"%(p,q)
#     cursor.execute(sql2)
  
#     if(cursor.rowcount) > 0:
   
#         result1=cursor.fetchall()
#         for row in result1:
#             request.session['uid']=row[1]
#             request.session['uname']=row[2]
#             request.session['upass']=row[3]
#             request.session['utype']=row[4]

#         if(request.session['utype']=='admin'): 
#             return render(request,'adminhome.html')
		
#         elif(request.session['utype']=='StoreMaster'):
# 	        return render(request,'storeHome.html')
        
#     else:
#         html="<script>alert('invalid password and username');window.location='/login/';</script>"
#         return HttpResponse(html)



def searchlogin(request):
    cursor = connection.cursor()
    p = request.POST['uname']
    q = request.POST['upass']
    sql2 = "SELECT * FROM login WHERE uname=%s AND upass=%s"
    cursor.execute(sql2, [p, q])
    
    if cursor.rowcount > 0:
        result1 = cursor.fetchall()
        for row in result1:
            request.session['uid'] = row[1]
            request.session['uname'] = row[2]
            request.session['upass'] = row[3]
            request.session['utype'] = row[4]

        if request.session['utype'] == 'admin': 
            return render(request, 'adminhome.html')
        elif request.session['utype'] == 'StoreMaster':
            return render(request, 'storeHome.html')
    else:
        html = "<script>alert('Invalid username or password');window.location='/login/';</script>"
        return HttpResponse(html)

def adminHome(request):
    return render(request,'adminHome.html')
def customerhome(request):
    return render(request,'customerhome.html')


def store(request):
    cur=connection.cursor()
    s="select * from store"
    cur.execute(s)
    list2=[]
    rs=cur.fetchall()
    for row in rs:
        w={'stid':row[0],'sname':row[1],'adr':row[2],'ph':row[3],'em':row[4],'smname':row[5]}
        list2.append(w)
    return render(request,'store.html',{'list2':list2})
    


def StoreAct(request):  
    cur = connection.cursor()
    
    sname = request.GET['sname']
    adr = request.GET['adr']
    ph = request.GET['ph']
    em = request.GET['em']
    smname = request.GET['smname']
    psw = request.GET['upass']
    
    a1 = "select * from store where em='%s'" % (em)
    cur.execute(a1)
    
    if cur.rowcount > 0:
        msg = "<script>alert('Already Exist');window.location='/store/'</script>"
        return HttpResponse(msg)
    else:
        sql = "insert into store (sname, adr, ph, em, smname) values ('%s', '%s', '%s', '%s', '%s')" % (sname, adr, ph, em, smname)
        cur.execute(sql)
        
        sq = "select max(stid) as stid from store"
        cur.execute(sq)
        cr = cur.fetchall()
        
        for row in cr:
            q = "insert into login (uid, uname, upass, utype) values ('%s', '%s', '%s', 'StoreMaster')" % (row[0], em, psw)
            cur.execute(q)
        
        s = "select * from store"
        cur.execute(s)
        
        list2 = []
        rs = cur.fetchall()
        
        for row in rs:
            w = {'stid': row[0], 'sname': row[1], 'adr': row[2], 'ph': row[3], 'em': row[4], 'smname': row[5]}
            list2.append(w)
    
    return render(request, 'store.html', {'list2': list2})

def delStore(request):
    cur=connection.cursor()
    stid=request.GET['stid']
    cur.execute("delete from store where stid='%s'"%(stid))
    cur.execute("delete from login where uid='%s'"%(stid))
    msg="<script>alert('Deleted');window.location='/store/'</script>"
    return HttpResponse(msg)

def supplier(request):
    cur=connection.cursor()
    s="select * from supplier"
    cur.execute(s)
    list2=[]
    rs=cur.fetchall()
    for row in rs:
        w={'sid':row[0],'sname':row[1],'adr':row[2],'ph':row[3],'em':row[4]}
        list2.append(w)
    return render(request,'supplier.html',{'list2':list2})
def supplierAct(request):
    cur=connection.cursor()
    sname=request.GET['sname']
    adr=request.GET['adr']
    ph=request.GET['ph']
    em=request.GET['em']
    s1="select * from supplier where ph='%s' and em='%s'"%(ph,em)
    cur.execute(s1)
    if(cur.rowcount) > 0:
        msg="<script>alert('Already Exist this Email and Contact No');window.location='/supplier/'</script>"
        return HttpResponse(msg)
    else:
        sql="insert into supplier (sname,adr,ph,em) values('%s','%s','%s','%s')"%(sname,adr,ph,em)
        cur.execute(sql)
        s="select * from supplier"
        cur.execute(s)
        list2=[]
        rs=cur.fetchall()
        for row in rs:
            w={'sid':row[0],'sname':row[1],'adr':row[2],'ph':row[3],'em':row[4]}
            list2.append(w)
    return render(request,'supplier.html',{'list2':list2})
def delSupplier(request):
    cur=connection.cursor()
    sid=request.GET['sid']
    cur.execute("delete from supplier where sid='%s'"%(sid))
    msg="<script>alert('Deleted');window.location='/supplier/'</script>"
    return HttpResponse(msg)
    #return render(request,'storeHome.html')
def storeHome(request):
    return render(request,'storeHome.html')


def report(request):
    return render(request,'report.html')
def reportaction(request):
    cursor=connection.cursor()
    fd=request.GET['fd']
    td=request.GET['td']
    list=[]
    s=" select p.pdate,s.sname,v.vname,i.iname,pc.tqty,pc.uprice from tbl_purchasemaster as p inner join store as s on p.stid = s.stid  inner join vendor as v on p.vid = v.vid inner join tbl_pchild as pc on p.pmid = pc.pmid  inner join item as i on pc.icode=i.icode where p.pdate between '%s' and '%s' " %(fd,td)
    print(s)
    cursor.execute(s)
    result=cursor.fetchall()
    for row in result:
        w={'pdate':row[0],'sname':row[1],'vname':row[2],'iname':row[3],'tqty':row[4],'uprice':row[5]}
        list.append(w)
    return render(request,'reportact.html',{'list':list,})


def product(request):
    cur=connection.cursor()
    list=[]
    s="select * from item inner join tbl_category on item.catid = tbl_category.catid inner join tbl_subcategory on item.subid = tbl_subcategory.subid "
    print(s)
    cur.execute(s)
    result=cur.fetchall()
    for row in result:
        w={'icode':row[0],'iname':row[1],'catid':row[2],'subid':row[3],'desp':row[4],'mrp':row[5],'qty':row[6],'img':row[7],'cname':row[9],'sname':row[12]}
        list.append(w)
    list1=[]
    s="select * from tbl_category"
    cur.execute(s)
    result=cur.fetchall()
    for row in result:
        w={'catid':row[0],'cname':row[1],'cdesp':row[2]}
        list1.append(w)
    list2 =[]
    s="select * from tbl_subcategory"
    cur.execute(s)
    result=cur.fetchall()
    for row in result:
        w={'subid':row[0],'sname':row[1],'sdesp':row[2],'catid':row[3]}
        list2.append(w)
        return render(request,'product.html',{'list':list,'list1':list1,'list2':list2})
    
def productaction(request):
    if request.method == "POST":
         MyProfileForm = iform(request.POST, request.FILES)
         if MyProfileForm.is_valid():
              profile =imodel()
              profile.icode= MyProfileForm.cleaned_data["icode"]
              profile.iname= MyProfileForm.cleaned_data['iname']
              profile.catid= MyProfileForm.cleaned_data['cat']
              profile.subid= MyProfileForm.cleaned_data['sub']
              profile.desp= MyProfileForm.cleaned_data['desp']
              profile.mrp= MyProfileForm.cleaned_data['mrp']
              profile.qty= MyProfileForm.cleaned_data['qty']
              profile.img= MyProfileForm.cleaned_data['img']
              profile.save()
              h="<script>alert('successfully added');window.location='/product/';</script>"
              saved = True
    else:
         MyProfileForm = iform()
    return HttpResponse(h)



def purchase(request): 
    cur=connection.cursor()
    list=[]
    s="select * from tbl_prequest inner join vendor on vendor.vid=tbl_prequest.vid inner join item on item.icode = tbl_prequest.icode"
    cur.execute(s)
    result=cur.fetchall()
    for row in result:
        w={'rqid':row[0],'vid':row[1],'rdate':row[2],'icode':row[3],'stid':row[4],'status':row[5],'vname':row[7],'iname':row[12]}
        list.append(w)
    list1=[]
    s="select * from vendor"
    cur.execute(s)
    result1=cur.fetchall()
    for row in result1:
        w={'vid':row[0],'vname':row[1],'vadd':row[2],'vph':row[3],'vem':row[4]}
        list1.append(w)
    list2=[]
    s="select * from item"
    cur.execute(s)
    result2=cur.fetchall()
    for row in result2:
        w={'icode':row[0],'iname':row[1]}
        list2.append(w)    
    return render(request,"purchase.html",{'list':list,'list1':list1,'list2':list2})
def purchaseaction(request):
    cursor=connection.cursor()
    uid=request.session['uid']
    vname=request.GET['vname']
    icode=request.GET['icode']
    # smname=request.GET['smname']
    #tqty=request.GET['tqty']
    #totalam=request.GET['totalam']
    sql="insert into tbl_prequest(vid,rdate,icode,stid,status) values ('%s','%s','%s','%s''%s')" %(vname,today,icode,uid,'pending')
    cursor.execute(sql)
    h="<script>alert('successfully inserted');window.location='/purchase/';</script>"
    return HttpResponse(h)

def purchasentry(request):
    cursor = connection.cursor()
    vid=request.GET['vid']
    c="select * from vendor"
    cursor.execute(c)
    re=cursor.fetchall()
    vend=[]
    for sy in re:
        y = {'vid':sy[0],'vname' : sy[1]}
        vend.append(y)
    if(request.session['utype']=='StoreMaster'):
        sql2="select tbl_purchasemaster.pmid,tbl_purchasemaster.pdate,tbl_purchasemaster.totalam,vendor.vname from tbl_purchasemaster  inner join vendor on tbl_purchasemaster.vid=vendor.vid where tbl_purchasemaster.stid='%s'"%(request.session['uid'])
    
    elif(request.session['utype']=='admin'):
        sql2="select tbl_purchasemaster.pmid,tbl_purchasemaster.pdate,tbl_purchasemaster.totalam,vendor.vname from tbl_purchasemaster  inner join vendor on tbl_purchasemaster.vid=vendor.vid"
    cursor.execute(sql2)
    re1=cursor.fetchall()
    pdt=[]
    for sy1 in re1:
        y1 = {'pmid':sy1[0],'pdate' : sy1[1],'totalam':sy1[2],'vname' : sy1[3]}
        pdt.append(y1)
    return render(request,'purchasentry.html', {'list':vend,'list1':pdt,'utype':request.session['utype'],'vid':vid})

def purchaseact(request):
    cursor=connection.cursor()
    vend=request.GET['vend']
    pdt=request.GET['pdt']
    st=request.session['uid']
    sql="insert into tbl_purchasemaster(stid,vid,pdate,totalam)values('%s','%s','%s','%s')"%(st,vend,pdt,'0')  
    cursor.execute(sql)
    h="<script>alert('success');window.location='/purchasentry?vid="+vend+"';</script>"
    return HttpResponse(h)

def pchild(request):
    cursor = connection.cursor()
    pmid=request.GET['pid']
    sql2="select tbl_pchild.*,item.iname from tbl_pchild inner join item on tbl_pchild.icode=item.icode where pmid='%s'"%(pmid)
    cursor.execute(sql2)
    result=cursor.fetchall()
    list=[]
    for row in result:
        w = {'pchild_id' : row[0],'pmid': row[1],'icode':row[2],'tqty':row[3],'uprice':row[4],'totalam':row[5],'iname':row[6]}
        list.append(w)
    list2=[]
    s="select * from item"
    cursor.execute(s)
    result=cursor.fetchall()
    for row in result:
        w={'icode':row[0],'iname':row[1],'catid':row[2],'subid':row[3],'desp':row[4],'mrp':row[5],'qty':row[6],'img':row[7]}
        list2.append(w)
    return render(request,'purchasechild.html', {'list1': list,'list2':list2,'pmid':pmid,'utype':request.session['utype']})

def purchildaction(request):
    cursor=connection.cursor()
    pmid=request.GET['t0']
    bid=request.GET['bid']
    qty=request.GET['tqt']
    uamt=request.GET['utpr']
    tamt=int(qty)*int(uamt)
    sql="insert into tbl_pchild(pmid,icode,tqty,uprice,totalam) values('%s','%s','%s','%s','%s')"%(pmid,bid,qty,uamt,tamt)
    cursor.execute(sql)
    sql2="select totalam from tbl_purchasemaster where pmid='%s'"%(pmid)
    cursor.execute(sql2)
    result=cursor.fetchall()
    for row in result:
         pm=row[0]
         pmn=int(pm)+tamt
         sql4="select qty from item where icode='%s'"%(bid)
         cursor.execute(sql4)
         result3=cursor.fetchall()
         for row3 in result3:
              bqty1=int(row3[0])
              bqty=bqty1+int(qty)
              sql3="update tbl_purchasemaster set totalam='%s'  where pmid='%s'"%(pmn,pmid)
              cursor.execute(sql3)
              sql5="update item set qty='%s'  where icode='%s'"%(bqty,bid)
              cursor.execute(sql5)
              h="<script>window.location='/pchild?pid=%s';</script>"%(pmid)
         return HttpResponse(h)
def delpchild(request):
    cur=connection.cursor()
    id=request.GET['id']
    cur.execute("delete from tbl_pchild where pchild_id='%s'"%(id))
    msg="<script>alert('Deleted');window.location='/purchasentry/'</script>"
    return HttpResponse(msg)



def purchasereq(request):
    cur=connection.cursor()
    list1=[]
    s="SELECT * FROM tbl_prequest inner join store on store.stid=tbl_prequest.stid inner join vendor on vendor.vid=tbl_prequest.vid inner join item on tbl_prequest.icode=item.icode"
    cur.execute(s)
    result=cur.fetchall()
    for row in result:
        # w={'rqid':row[6],'vname':row[14],'rdate':row[8],'smname':row[5],'tqty':row[10],'totalam':row[11],'status':row[12]}
        w={'rqid':row[0],'vid':row[1],'rdate':row[2],'icode':row[3],'stid':row[4],'status':row[5],'vname':row[13],'iname':row[18],'smname':row[11]}
        list1.append(w)
    return render(request,"purchasereq.html",{'list1':list1})   	
def delp(request):
	cursor=connection.cursor()
	n=request.GET['n']
	sql="update tbl_prequest set status ='Accepted' where rqid='%s'" %(n)
	cursor.execute(sql)
	h="<script>alert('success');window.location='/purchasereq/';</script>"
	return HttpResponse(h)
def delr(request):
    cursor=connection.cursor()
    n=request.GET['d']
    sql="update tbl_prequest set status ='Rejected' where rqid='%s'" %(n)
    cursor.execute(sql)
    h="<script>alert('success');window.location='/purchasereq/';</script>"
    return HttpResponse(h)

def stock(request):
    cur=connection.cursor()
    list=[]
    s="select * from item inner join tbl_category on item.catid = tbl_category.catid inner join tbl_subcategory on item.subid = tbl_subcategory.subid "
    cur.execute(s)
    result=cur.fetchall()
    for row in result:
        w={'icode':row[0],'iname':row[1],'catid':row[2],'subid':row[3],'desp':row[4],'mrp':row[5],'qty':row[6],'cname':row[8],'sname':row[11]}
        list.append(w)
    return render(request,"stock.html",{'list':list})
def delstock(request):
	cursor=connection.cursor()
	n=request.GET['n']
	sql="delete from item where icode='%s'"%(n)
	cursor.execute(sql)
	h="<script>alert('success');window.location='/stock/';</script>"
	return HttpResponse(h)  


def vendor(request): 
    cur=connection.cursor()
    list=[]
    s="select * from vendor "
    cur.execute(s)
    result=cur.fetchall()
    for row in result:
        w={'vid':row[0],'vname':row[1],'vadd':row[2],'vph':row[3],'vem':row[4]}
        list.append(w)
    return render(request,"vendor.html",{'list':list})
def vendoraction(request):
    cursor=connection.cursor()
    vname=request.GET['vname']
    vadd=request.GET['vadd']
    vph=request.GET['vph']
    vem=request.GET['vem']
    sql="insert into vendor(vname,vadd,vph,vem) values ('%s','%s','%s','%s')" %(vname,vadd,vph,vem)
    cursor.execute(sql)
    h="<script>alert('successfully inserted');window.location='/vendor/';</script>"
    return HttpResponse(h)

def cat(request):
	cur=connection.cursor()
	list=[]
	s="select* from tbl_category"
	cur.execute(s)
	result=cur.fetchall()
	for row in result:
		w={'catid':row[0],'cname':row[1],'cdesp':row[2]}
		list.append(w)
	return list
def catload(request):
    cur=connection.cursor()
    list=[]
    s="select* from tbl_category"
    cur.execute(s)
    result=cur.fetchall()
    for row in result:
        w={'catid':row[0],'cname':row[1],'cdesp':row[2]}
        list.append(w)
    return render(request,'category.html',{'list':list})
def cataction(request):
	cursor=connection.cursor()
	name=request.GET['cname']
	des=request.GET['cdes']
	sql="insert into tbl_category(cname,cdesp) values ('%s','%s')" %(name,des)
	cursor.execute(sql)
	h="<script>alert('successfully inserted');window.location='/catload/';</script>"
	return HttpResponse(h)
def delcat(request):
	cursor=connection.cursor()
	n=request.GET['n']
	sql="delete from tbl_category where catid='%s'"%(n)
	cursor.execute(sql)
	h="<script>alert('success');window.location='/catload/';</script>"
	return HttpResponse(h)
def viewcat(request):
	cur=connection.cursor()
	list=[]
	s="select* from tbl_category"
	cur.execute(s)
	result=cur.fetchall()
	for row in result:
		w={'catid':row[0],'cname':row[1],'cdesp':row[2]}
		list.append(w)
	return render(request,'category_view.html',{'list':list})


def subcat(request):
	cur=connection.cursor()
	list=[]
	s="SELECT s.subid,s.sname,s.sdesp,c.cname AS category_name FROM tbl_subcategory s JOIN tbl_category c ON s.catid = c.catid"
	cur.execute(s)
	result=cur.fetchall()
	for row in result:
		w={'subid':row[0],'sname':row[1],'sdesp':row[2],'catid':row[3]}
		list.append(w)
	return list
def subcatload(request):
	list=cat(request)
	list1=subcat(request)
	return render(request,'subcategory.html',{'list':list,'sub':list1})
def subcataction(request):
	cur=connection.cursor()
	name=request.GET['scname']
	des=request.GET['scdes']
	cat=request.GET['cname']
	sql="insert into tbl_subcategory(sname,sdesp,catid) values ('%s','%s','%s')" %(name,des,cat)
	cur.execute(sql)
	h="<script>alert('successfully inserted');window.location='/subcatload/';</script>"
	return HttpResponse(h)
def delsubcat(request):
	cursor=connection.cursor()
	n=request.GET['n']
	sql="delete from tbl_subcategory where subid='%s'"%(n)
	cursor.execute(sql)
	h="<script>alert('success');window.location='/subcatload/';</script>"
	return HttpResponse(h)
def viewsubcat(request):
	cur=connection.cursor()
	list=[]
	s="select* from tbl_subcategory"
	cur.execute(s)
	result=cur.fetchall()
	for row in result:
		w={'subid':row[0],'sname':row[1],'sdesp':row[2],'catid':row[3]}
		list.append(w)
	return render(request,'subcategory_view.html',{'list':list})