-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 05, 2024 at 06:44 AM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pms`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(2, 'auth', 'permission'),
(3, 'auth', 'group'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE IF NOT EXISTS `django_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2024-02-10 08:52:22.868614'),
(2, 'auth', '0001_initial', '2024-02-10 08:52:22.951318'),
(3, 'admin', '0001_initial', '2024-02-10 08:52:23.213019'),
(4, 'admin', '0002_logentry_remove_auto_add', '2024-02-10 08:52:23.292102'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2024-02-10 08:52:23.297824'),
(6, 'contenttypes', '0002_remove_content_type_name', '2024-02-10 08:52:23.350082'),
(7, 'auth', '0002_alter_permission_name_max_length', '2024-02-10 08:52:23.369198'),
(8, 'auth', '0003_alter_user_email_max_length', '2024-02-10 08:52:23.399716'),
(9, 'auth', '0004_alter_user_username_opts', '2024-02-10 08:52:23.404698'),
(10, 'auth', '0005_alter_user_last_login_null', '2024-02-10 08:52:23.429804'),
(11, 'auth', '0006_require_contenttypes_0002', '2024-02-10 08:52:23.432795'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2024-02-10 08:52:23.439821'),
(13, 'auth', '0008_alter_user_username_max_length', '2024-02-10 08:52:23.471134'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2024-02-10 08:52:23.493649'),
(15, 'auth', '0010_alter_group_name_max_length', '2024-02-10 08:52:23.519900'),
(16, 'auth', '0011_update_proxy_permissions', '2024-02-10 08:52:23.528266'),
(17, 'sessions', '0001_initial', '2024-02-10 08:52:23.540877');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('4wu3m6clfeuw98m733wdztfvmqcooclq', 'OGNkYzJhMTYxOWQ5MWQyZTU0ZDRjMDZkY2QyZDU1ZDQxMzljYjdmOTp7InVpZCI6MCwidW5hbWUiOiJhZG1pbiIsInVwYXNzIjoiYWRtaW4iLCJ1dHlwZSI6ImFkbWluIn0=', '2024-03-01 04:38:20.245864'),
('tkt3441cqfr8uqydiko1795qa83mc42e', 'OGNkYzJhMTYxOWQ5MWQyZTU0ZDRjMDZkY2QyZDU1ZDQxMzljYjdmOTp7InVpZCI6MCwidW5hbWUiOiJhZG1pbiIsInVwYXNzIjoiYWRtaW4iLCJ1dHlwZSI6ImFkbWluIn0=', '2024-03-06 07:56:05.329832'),
('02i1wv6mxr0cqr7p291fsw8gnoh3ju4q', 'OGNkYzJhMTYxOWQ5MWQyZTU0ZDRjMDZkY2QyZDU1ZDQxMzljYjdmOTp7InVpZCI6MCwidW5hbWUiOiJhZG1pbiIsInVwYXNzIjoiYWRtaW4iLCJ1dHlwZSI6ImFkbWluIn0=', '2024-03-07 05:03:39.922340'),
('imbjmt0p0qs03pcxv0xj84d31psg2m2i', 'OGNkYzJhMTYxOWQ5MWQyZTU0ZDRjMDZkY2QyZDU1ZDQxMzljYjdmOTp7InVpZCI6MCwidW5hbWUiOiJhZG1pbiIsInVwYXNzIjoiYWRtaW4iLCJ1dHlwZSI6ImFkbWluIn0=', '2024-03-09 05:05:43.465609'),
('7jvabfq6flee7qxg9xr27wjrz3cv7e5f', 'OGNkYzJhMTYxOWQ5MWQyZTU0ZDRjMDZkY2QyZDU1ZDQxMzljYjdmOTp7InVpZCI6MCwidW5hbWUiOiJhZG1pbiIsInVwYXNzIjoiYWRtaW4iLCJ1dHlwZSI6ImFkbWluIn0=', '2024-03-11 04:16:44.412774'),
('c70zdz8jxjujyqxsfrc78cgzoprd7fqt', 'OGNkYzJhMTYxOWQ5MWQyZTU0ZDRjMDZkY2QyZDU1ZDQxMzljYjdmOTp7InVpZCI6MCwidW5hbWUiOiJhZG1pbiIsInVwYXNzIjoiYWRtaW4iLCJ1dHlwZSI6ImFkbWluIn0=', '2024-03-11 06:06:37.916192'),
('2q04bga98ehs6xl2ab9rqwygod3pwqwy', 'OGNkYzJhMTYxOWQ5MWQyZTU0ZDRjMDZkY2QyZDU1ZDQxMzljYjdmOTp7InVpZCI6MCwidW5hbWUiOiJhZG1pbiIsInVwYXNzIjoiYWRtaW4iLCJ1dHlwZSI6ImFkbWluIn0=', '2024-03-23 04:16:21.610488'),
('cexzoogxacpjr2q9040odgh4qxqi6g8y', 'OGNkYzJhMTYxOWQ5MWQyZTU0ZDRjMDZkY2QyZDU1ZDQxMzljYjdmOTp7InVpZCI6MCwidW5hbWUiOiJhZG1pbiIsInVwYXNzIjoiYWRtaW4iLCJ1dHlwZSI6ImFkbWluIn0=', '2024-03-26 04:14:32.794100'),
('mywqu85868q4aiu45zs1mvfji89zj3gm', '.eJyrVirNTFGyMtBRKs1LzE1VslJKTMnNzFMC8gsSi4uR-SWVBQj5WgAHGRJH:1s4DtS:mj1dFH6EMhtbkx5_pLp5gOHaNLcCTDH6TQCrYA2_OPw', '2024-05-21 06:01:38.670482'),
('7bzpuv97acux331hn1lrge0b0ivqi7xg', 'eyJ1aWQiOjEsInVuYW1lIjoiczFAZ21haWwuY29tIiwidXBhc3MiOiIxMjMiLCJ1dHlwZSI6IlN0b3JlTWFzdGVyIn0:1s5KAk:aYBYf41cLbuChDDCFdUCsiREldPSzzJshTHrmWWGFz8', '2024-05-24 06:56:02.451624'),
('7wfrvyaaxdnbqtunioh384fns7nahemq', '.eJyrVirNTFGyMtBRKs1LzE1VslJKTMnNzFMC8gsSi4uR-SWVBQj5WgAHGRJH:1s8BhN:edKsFr0ZuASSVcZko7bkWYLTIIymzPrDR49-F9fDkQU', '2024-06-01 04:29:33.491734'),
('b7jsljt2tdjq2wligzhocr69g6ygrgmp', '.eJyrVirNTFGyMtBRKs1LzE1VslJKTMnNzFMC8gsSi4uR-SWVBQj5WgAHGRJH:1s8CSW:nBmzhzQa4huzWYOHTwC3k9WzpkC8ijqRGiCxauVjdCw', '2024-06-01 05:18:16.788232'),
('ees7iicsdpktnprn1u47hyt5ah8mltez', '.eJyrVirNTFGyMtBRKs1LzE1VslJKTMnNzFMC8gsSi4uR-SWVBQj5WgAHGRJH:1s8w2o:vxT7R65zOoqe1Im_01Zr7w52_NPAHakL0oDmL5XQWBw', '2024-06-03 05:58:46.425826'),
('5en9m4ywlui2wruisegs0wnyf8nqra7s', '.eJyrVirNTFGyMtBRKs1LzE1VslJKTMnNzFMC8gsSi4uR-SWVBQj5WgAHGRJH:1s8yv0:FQQgxbYUaJvKxJMvrhIaF_Mzy_vKpSs-ZSFe811IMlE', '2024-06-03 09:02:54.423961'),
('khyd6zh9scr31npk5u5gkszivk43wvyr', '.eJyrVirNTFGyMtBRKs1LzE1VslJKTMnNzFMC8gsSi4uR-SWVBQj5WgAHGRJH:1s90BL:UngmokMdOuabaLT2AAFTKh1y0KN2lle3-rDecvMO9IM', '2024-06-03 10:23:51.002955'),
('pfoenotevbgtr94ufq0lf1tj2l9ae953', '.eJyrVirNTFGyMtBRKs1LzE1VslJKTMnNzFMC8gsSi4uR-SWVBQj5WgAHGRJH:1s9dUm:JXuHw8FB1Nt87Mg-afL1-eKdqjAMh3OHSeKtZ7UtIeM', '2024-06-05 04:22:32.634334'),
('5jlezaunt35geilfdzmv3zrp5qoz7eji', '.eJyrVirNTFGyMtBRKs1LzE1VslJKTMnNzFMC8gsSi4uR-SWVBQj5WgAHGRJH:1sEjX2:__IsFkLHWSY2ABXo0a6W8oNLWVXYu5RzrdHl0rAtq-M', '2024-06-19 05:49:56.306394'),
('3wqwjc65p0uhqg1lm8xatr0stb3wr2u4', 'eyJ1aWQiOjIsInVuYW1lIjoiczJAZ21haWwuY29tIiwidXBhc3MiOiIxMjMiLCJ1dHlwZSI6IlN0b3JlTWFzdGVyIn0:1sPcT6:jmYp9N1P10_GlBUED60thMDEcu8D5Oq2gA3mwEAZ7ic', '2024-07-19 06:30:52.731036');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

DROP TABLE IF EXISTS `item`;
CREATE TABLE IF NOT EXISTS `item` (
  `icode` varchar(20) NOT NULL DEFAULT '',
  `iname` varchar(30) DEFAULT NULL,
  `catid` int DEFAULT NULL,
  `subid` int DEFAULT NULL,
  `desp` varchar(1000) DEFAULT NULL,
  `mrp` int DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `img` varchar(1000) NOT NULL,
  PRIMARY KEY (`icode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`icode`, `iname`, `catid`, `subid`, `desp`, `mrp`, `qty`, `img`) VALUES
('54', 'arun icecream', 7, 4, 'ice', 200, 178, 'img/images_uSVC109.jpg'),
('e1', 'egg', 7, 4, 'egg', 233, 45, 'img/images_x5eR0LX.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `lid` int NOT NULL AUTO_INCREMENT,
  `uid` int NOT NULL,
  `uname` varchar(60) NOT NULL,
  `upass` varchar(60) NOT NULL,
  `utype` varchar(60) NOT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`lid`, `uid`, `uname`, `upass`, `utype`) VALUES
(1, 0, 'admin', 'admin', 'admin'),
(14, 2, 's2@gmail.com', '123', 'StoreMaster'),
(19, 7, 'zudio@gmail.com', 'ziza', 'StoreMaster');

-- --------------------------------------------------------

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
CREATE TABLE IF NOT EXISTS `store` (
  `stid` int NOT NULL AUTO_INCREMENT,
  `sname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `adr` varchar(100) NOT NULL,
  `ph` varchar(12) NOT NULL,
  `em` varchar(100) NOT NULL,
  `smname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`stid`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `store`
--

INSERT INTO `store` (`stid`, `sname`, `adr`, `ph`, `em`, `smname`) VALUES
(2, 'Store2', 'addddf', '4555555554', 's2@gmail.com', 'Ginu'),
(7, 'zudio', 'adoor', '1234567899', 'zudio@gmail.com', 'ziza');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
CREATE TABLE IF NOT EXISTS `supplier` (
  `sid` int NOT NULL AUTO_INCREMENT,
  `sname` varchar(60) NOT NULL,
  `adr` varchar(100) NOT NULL,
  `ph` varchar(12) NOT NULL,
  `em` varchar(100) NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`sid`, `sname`, `adr`, `ph`, `em`) VALUES
(14, 'dhashamulam dhamu', 'dham road', '4567888888', 'd@gmail.com'),
(13, 'pushpa', 'ross villa', '1234546787', 'pushpa@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

DROP TABLE IF EXISTS `tbl_category`;
CREATE TABLE IF NOT EXISTS `tbl_category` (
  `catid` int NOT NULL AUTO_INCREMENT,
  `cname` varchar(20) DEFAULT NULL,
  `cdesp` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`catid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`catid`, `cname`, `cdesp`) VALUES
(7, 'food', 'food');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pchild`
--

DROP TABLE IF EXISTS `tbl_pchild`;
CREATE TABLE IF NOT EXISTS `tbl_pchild` (
  `pchild_id` int NOT NULL AUTO_INCREMENT,
  `pmid` int NOT NULL,
  `icode` varchar(20) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tqty` int NOT NULL,
  `uprice` int NOT NULL,
  `totalam` int NOT NULL,
  PRIMARY KEY (`pchild_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_pchild`
--

INSERT INTO `tbl_pchild` (`pchild_id`, `pmid`, `icode`, `tqty`, `uprice`, `totalam`) VALUES
(24, 16, '54', 5, 4, 20),
(25, 17, '54', 23, 34, 782);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_prequest`
--

DROP TABLE IF EXISTS `tbl_prequest`;
CREATE TABLE IF NOT EXISTS `tbl_prequest` (
  `rqid` int NOT NULL AUTO_INCREMENT,
  `vid` int NOT NULL,
  `rdate` date NOT NULL,
  `icode` int NOT NULL,
  `stid` int NOT NULL,
  `status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`rqid`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `tbl_prequest`
--

INSERT INTO `tbl_prequest` (`rqid`, `vid`, `rdate`, `icode`, `stid`, `status`) VALUES
(15, 5, '2024-07-03', 0, 7, 'Accepted'),
(14, 4, '2024-07-03', 0, 7, 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_purchasemaster`
--

DROP TABLE IF EXISTS `tbl_purchasemaster`;
CREATE TABLE IF NOT EXISTS `tbl_purchasemaster` (
  `pmid` int NOT NULL AUTO_INCREMENT,
  `stid` int DEFAULT NULL,
  `vid` int DEFAULT NULL,
  `pdate` date DEFAULT NULL,
  `totalam` int DEFAULT NULL,
  PRIMARY KEY (`pmid`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_purchasemaster`
--

INSERT INTO `tbl_purchasemaster` (`pmid`, `stid`, `vid`, `pdate`, `totalam`) VALUES
(16, 7, 4, '2024-07-18', 20),
(17, 2, 4, '2024-07-17', 782),
(18, 2, 5, '2024-07-20', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subcategory`
--

DROP TABLE IF EXISTS `tbl_subcategory`;
CREATE TABLE IF NOT EXISTS `tbl_subcategory` (
  `subid` int NOT NULL AUTO_INCREMENT,
  `sname` varchar(20) DEFAULT NULL,
  `sdesp` varchar(1000) DEFAULT NULL,
  `catid` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`subid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_subcategory`
--

INSERT INTO `tbl_subcategory` (`subid`, `sname`, `sdesp`, `catid`) VALUES
(4, 'icecream', 'icecream', '7');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

DROP TABLE IF EXISTS `vendor`;
CREATE TABLE IF NOT EXISTS `vendor` (
  `vid` int NOT NULL AUTO_INCREMENT,
  `vname` varchar(100) NOT NULL,
  `vadd` varchar(100) NOT NULL,
  `vph` int NOT NULL,
  `vem` varchar(100) NOT NULL,
  PRIMARY KEY (`vid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`vid`, `vname`, `vadd`, `vph`, `vem`) VALUES
(4, 'amban', 'ranga house ,bangalore', 2147483647, 'annanistam@gmail.com'),
(5, 'ranga', 'ranga bangalore', 999999999, 'r@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
