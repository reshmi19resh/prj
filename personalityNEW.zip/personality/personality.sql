-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 18, 2023 at 12:37 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `personality`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `auth_group`
--


-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group_permissi_permission_id_23962d04_fk_auth_permission_id` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `auth_group_permissions`
--


-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can add permission', 2, 'add_permission'),
(5, 'Can change permission', 2, 'change_permission'),
(6, 'Can delete permission', 2, 'delete_permission'),
(7, 'Can add group', 3, 'add_group'),
(8, 'Can change group', 3, 'change_group'),
(9, 'Can delete group', 3, 'delete_group'),
(10, 'Can add user', 4, 'add_user'),
(11, 'Can change user', 4, 'change_user'),
(12, 'Can delete user', 4, 'delete_user'),
(13, 'Can add content type', 5, 'add_contenttype'),
(14, 'Can change content type', 5, 'change_contenttype'),
(15, 'Can delete content type', 5, 'delete_contenttype'),
(16, 'Can add session', 6, 'add_session'),
(17, 'Can change session', 6, 'change_session'),
(18, 'Can delete session', 6, 'delete_session');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `auth_user`
--


-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_30a071c9_fk_auth_group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `auth_user_groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_user_perm_permission_id_3d7071f0_fk_auth_permission_id` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `auth_user_user_permissions`
--


-- --------------------------------------------------------

--
-- Table structure for table `bigfive`
--

CREATE TABLE IF NOT EXISTS `bigfive` (
  `uid` int(11) NOT NULL,
  `O` int(11) NOT NULL,
  `C` int(11) NOT NULL,
  `E` int(11) NOT NULL,
  `A` int(11) NOT NULL,
  `N` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bigfive`
--

INSERT INTO `bigfive` (`uid`, `O`, `C`, `E`, `A`, `N`) VALUES
(1, 23, 20, 14, 22, 11);

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin__content_type_id_5151027a_fk_django_content_type_id` (`content_type_id`),
  KEY `django_admin_log_user_id_1c5f563_fk_auth_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `django_admin_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_3ec8c61c_uniq` (`app_label`,`model`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE IF NOT EXISTS `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2022-12-26 07:22:46'),
(2, 'auth', '0001_initial', '2022-12-26 07:22:52'),
(3, 'admin', '0001_initial', '2022-12-26 07:22:53'),
(4, 'contenttypes', '0002_remove_content_type_name', '2022-12-26 07:22:53'),
(5, 'auth', '0002_alter_permission_name_max_length', '2022-12-26 07:22:53'),
(6, 'auth', '0003_alter_user_email_max_length', '2022-12-26 07:22:54'),
(7, 'auth', '0004_alter_user_username_opts', '2022-12-26 07:22:54'),
(8, 'auth', '0005_alter_user_last_login_null', '2022-12-26 07:22:54'),
(9, 'auth', '0006_require_contenttypes_0002', '2022-12-26 07:22:54'),
(10, 'sessions', '0001_initial', '2022-12-26 07:22:55');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('0mdrd6egwissddwvf8dzjklaube2noua', 'NmM1N2QxMGM3YTdhOTY1NWUyYmRjMzNiNmQyOGEyN2U2NGNjNzQyZjp7InV0eXBlIjoiYWRtaW4iLCJ1aWQiOjB9', '2023-01-09 07:32:46'),
('82y237lja4sj6ishl610une3it7xxsr7', 'NGY0YmUzNWE2ZGQ0YzczZTIwMDVkNWE4OWFkMDM2MzdhNmQ3OWI2Njp7InV0eXBlIjoidXNlciIsInVpZCI6IjE0In0=', '2023-01-10 08:21:44'),
('cj5dvwitys4du406c9bs8a2d18lu50xs', 'NzVhZWNhN2U2ZDhlZGM4ODUwMjgwMTdjNTg0NGYzMWQ4NDU1ZmFlZTp7InV0eXBlIjoidXNlciIsInVpZCI6IjEifQ==', '2023-02-01 07:01:37'),
('ee5wnc0gw9l2xn6h668hj1txqv0t8cyq', 'eyJ1aWQiOiIwIiwidXR5cGUiOiJhZG1pbiJ9:1pI7W0:cgx_7io5Q1W6nqJGY9aIMoFzNTdxKvchmm68nSIAmyo', '2023-02-01 12:26:04'),
('mqohngscg6bz8j4brrnhb0t51meeh6y8', 'MDk0MmY5ZDAyOGE0NzQ0NmVjZmNjOTM2Y2IwMWUxZTE4YmMyNzRhMzp7InV0eXBlIjoiYWRtaW4iLCJ1aWQiOiIwIn0=', '2023-01-30 11:30:37'),
('n14ey7ymdq5guhc4jp7k6wek60wj3b70', 'NzVhZWNhN2U2ZDhlZGM4ODUwMjgwMTdjNTg0NGYzMWQ4NDU1ZmFlZTp7InV0eXBlIjoidXNlciIsInVpZCI6IjEifQ==', '2023-02-01 09:46:18');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE IF NOT EXISTS `job` (
  `jid` int(10) NOT NULL AUTO_INCREMENT,
  `jbname` varchar(50) DEFAULT NULL,
  `jbdec` varchar(100) DEFAULT NULL,
  `lds` varchar(20) DEFAULT NULL,
  `salary` varchar(20) DEFAULT NULL,
  `edc` varchar(50) DEFAULT NULL,
  `pdte` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`jid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`jid`, `jbname`, `jbdec`, `lds`, `salary`, `edc`, `pdte`) VALUES
(1, 'Developer', 'Strong Kownledge for Html, Java, spring, css', '2023-01-31', '20000 per month', 'MCA or B.tech', '2023-01-17'),
(2, 'Developer', 'Freshers can apply', '2023-02-18', '10000-15000', 'Any degreee', '2023-01-17');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `lid` int(30) NOT NULL AUTO_INCREMENT,
  `uid` varchar(10) DEFAULT NULL,
  `uname` varchar(50) DEFAULT NULL,
  `upass` varchar(30) DEFAULT NULL,
  `utype` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`lid`, `uid`, `uname`, `upass`, `utype`) VALUES
(1, '0', 'admin', 'admin', 'admin'),
(2, '1', 'sree@gmail.com', 'sree@123', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `ocean`
--

CREATE TABLE IF NOT EXISTS `ocean` (
  `openness` varchar(50) NOT NULL,
  `conscientiousness` varchar(50) NOT NULL,
  `extraversion` varchar(50) NOT NULL,
  `agreeableness` varchar(50) NOT NULL,
  `neuroticism` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ocean`
--

INSERT INTO `ocean` (`openness`, `conscientiousness`, `extraversion`, `agreeableness`, `neuroticism`) VALUES
('Imaginative', 'Thoughtful', 'Cheerful', 'Trustworthy', 'Calm'),
('Insightful', 'Goal-oriented', 'Sociable', 'Altruism', 'Strong hearted'),
('Curious', 'Ambitious', 'Talkative', 'Kind', 'Collected'),
('Creative', 'Organised', 'Assertive', 'Affectionate', 'Balanced'),
('Outspoken', 'Mindful', 'Outgoing', 'Cooperative', 'Peaceful'),
('Straightforward', 'Vigilant', 'Energetic', 'Empathetic', 'Tranquil'),
('Direct', 'Control', 'Extroverted', 'Modest', 'Strong-willed'),
('Receptive', 'Disciplined', 'Friendly', 'Sympathetic', 'Emotionally Stable'),
('Open-minded', 'Reliable', 'Enthusiastic', 'Compliant', 'Serene'),
('Adventurous', 'Responsible', 'Outspoken', 'Tender-mindedness', 'Resilient');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `uid` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `phn` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `pass` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`uid`, `name`, `phn`, `email`, `pass`) VALUES
(1, 'Sreelekshmi', '9876765434', 'sree@gmail.com', 'sree@123');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_apply`
--

CREATE TABLE IF NOT EXISTS `tbl_apply` (
  `aid` int(10) NOT NULL AUTO_INCREMENT,
  `uid` varchar(10) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `jid` varchar(10) DEFAULT NULL,
  `jname` varchar(50) DEFAULT NULL,
  `p_image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`aid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_apply`
--

INSERT INTO `tbl_apply` (`aid`, `uid`, `name`, `email`, `jid`, `jname`, `p_image`) VALUES
(1, '1', 'Sreelekshmi', NULL, '1', 'Developer', 'pictures/10.1.1.740.4766.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_basic`
--

CREATE TABLE IF NOT EXISTS `tbl_basic` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(100) DEFAULT NULL,
  `district` varchar(20) DEFAULT NULL,
  `pincode` varchar(20) DEFAULT NULL,
  `dob` varchar(10) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `uid` int(10) DEFAULT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_basic`
--

INSERT INTO `tbl_basic` (`bid`, `address`, `district`, `pincode`, `dob`, `gender`, `uid`) VALUES
(2, 'rose villa', 'tvm', '567889', '2000-03-12', 'male', NULL),
(3, 'Puthenveettil kizhakkathil, Edakkunnam, charummoodu', 'Alappuzha', '690505', '1993-12-18', 'female', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cvupload`
--

CREATE TABLE IF NOT EXISTS `tbl_cvupload` (
  `cid` int(10) NOT NULL AUTO_INCREMENT,
  `p_image` varchar(100) NOT NULL,
  `uid` varchar(10) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_cvupload`
--

INSERT INTO `tbl_cvupload` (`cid`, `p_image`, `uid`) VALUES
(1, 'pictures/10.1.1.740.4766.pdf', '1');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_education`
--

CREATE TABLE IF NOT EXISTS `tbl_education` (
  `edid` int(11) NOT NULL AUTO_INCREMENT,
  `hqua` varchar(20) DEFAULT NULL,
  `mark` varchar(20) DEFAULT NULL,
  `year` varchar(20) DEFAULT NULL,
  `univ` varchar(20) DEFAULT NULL,
  `exp` varchar(20) DEFAULT NULL,
  `rid` int(11) DEFAULT NULL,
  PRIMARY KEY (`edid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_education`
--

INSERT INTO `tbl_education` (`edid`, `hqua`, `mark`, `year`, `univ`, `exp`, `rid`) VALUES
(1, 'B.tech', '8.2', '2016-03-04', 'University of kerala', 'Experienced', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employer`
--

CREATE TABLE IF NOT EXISTS `tbl_employer` (
  `empid` int(11) NOT NULL AUTO_INCREMENT,
  `empyr` varchar(11) DEFAULT NULL,
  `emp` varchar(20) DEFAULT NULL,
  `ephno` varchar(20) DEFAULT NULL,
  `eemail` varchar(20) DEFAULT NULL,
  `ref` varchar(20) DEFAULT NULL,
  `remail` varchar(20) DEFAULT NULL,
  `ctc` varchar(20) DEFAULT NULL,
  `rid` int(11) DEFAULT NULL,
  PRIMARY KEY (`empid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbl_employer`
--

INSERT INTO `tbl_employer` (`empid`, `empyr`, `emp`, `ephno`, `eemail`, `ref`, `remail`, `ctc`, `rid`) VALUES
(1, '2', 'Sreelekshmi', '9876765434', 'sree@gmail.com', 'Jay', 'Jayst12@gmail.com', '18000', 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissions_group_id_58c48ba9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_group_permissi_permission_id_23962d04_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permissi_content_type_id_51277a81_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_30a071c9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_24702650_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permissions_user_id_7cd7acb6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  ADD CONSTRAINT `auth_user_user_perm_permission_id_3d7071f0_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_user_id_1c5f563_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  ADD CONSTRAINT `django_admin__content_type_id_5151027a_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);
