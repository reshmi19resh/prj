"""personality URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.8/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^', Home.as_view(), name='home')
Including another URLconf
    1. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.urls import include, path
from django.contrib import admin
from personalityapp.views import *
from django.views.generic import TemplateView
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
urlpatterns = [
    path(r'^admin/', (admin.site.urls)),
    path('register/',register,name="register"),
    path('login/',login,name="login"),
    path('', index,name="index"),
    path('index/',index,name="index"),
    path('basic/',basic,name="basic"),
    path('education/',education,name="education"),
    path('employer/',employer,name="employer"),
    path('regaction/',regaction,name="regaction"),
    path('basicaction/',basicaction,name="basicaction"),
    path('eduactionaction/',eduactionaction,name="eduactionaction"),
    path('employeraction/',employeraction,name="employeraction"),
    path('registerview/',registerview,name="registerview"),
    path('basicview/',basicview,name="basicview"),
    path('educationview/',educationview,name="educationview"),
    path('employerview/',employerview,name="employerview"),
    path('action_page/',action_page,name="action_page"),
    path('userhome/',userhome,name="userhome"),
    path('adminhome/',adminhome,name="adminhome"),
    path('cvanalyse/',cvanalyse,name="cvanalyse"),
    path('employerhome/',employerhome,name="employerhome"),
    path('regdel/',regdel,name="regdel"),
    path('basicdel/',basicdel,name="basicdel"),
    path('educationdel/',educationdel,name="educationdel"),
    path('employerdel/',employerdel,name="employerdel"),
    path('regup/',regup,name="regup"),
    path('regupaction/',regupaction,name="regupaction"),
    path('basicup/',basicup,name="basicup"),
    path('basicupaction/',basicupaction,name="basicupaction"),
    path('educationup/',educationup,name="educationup"),
    path('eduactionupaction/',eduactionupaction,name="eduactionupaction"),
    path('employerup/',employerup,name="employerup"),
    path('employerupaction/',employerupaction,name="employerupaction"),
    path('cvupload/',cvupload,name="cvupload"),
    path('job/',job,name="job"),
    path('jobaction/',jobaction,name="jobaction"),
    path('jobview/',jobview,name="jobview"),
    path('questions/',questions,name="questions"),
    path('sample/',sample,name="sample"),
    path('viewjob/',viewjob,name="viewjob"),
    path('jdel/',jdel,name="jdel"),
    path('jedit/',jedit,name="jedit"),
    path('jobupaction/',jobupaction,name="jobupaction"), 
    path('viewbasic/',viewbasic,name="viewbasic"),
    path('viewedu/',viewedu,name="viewedu"), 
    path('viewemp/',viewemp,name="viewemp"), 
    path('cvuploadaction/',cvuploadaction,name="cvuploadaction"),
    path('apply/',apply,name="apply"), 
    path('aplyaction/',aplyaction,name="aplyaction"),
    path('applyview/',applyview,name="applyviews"), 
    path('questionaction/',questionaction,name="questionaction"), 
    
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += staticfiles_urlpatterns()
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += staticfiles_urlpatterns()

