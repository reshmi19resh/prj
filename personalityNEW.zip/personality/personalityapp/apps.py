from django.apps import AppConfig


class ParserAppConfig(AppConfig):
    name = 'parser_app'
