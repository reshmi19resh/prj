from django import forms
from django.forms import CharField
from personalityapp.models import promodel
from personalityapp.models import amodel
class pform(forms.Form):
    p_image=forms.FileField()
    uid=forms.CharField(max_length=20)
    class Meta:
        model = promodel
        fields = ['p_image','uid']
class aform(forms.Form):
    uid=forms.CharField(max_length=20)
    name=forms.CharField(max_length=20)
    email=forms.CharField(max_length=20)
    jid=forms.CharField(max_length=20)
    jname=forms.CharField(max_length=20)
    p_image=forms.FileField()
    
    class Meta:
        model = amodel
        fields = ['uid','name','email','jid','jname','p_image']