from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import HttpResponseRedirect,redirect
from django.db import connection
from datetime import date
from .models import Resume, UploadResumeModelForm
from personalityapp.forms import pform
from personalityapp.models import promodel
from personalityapp.forms import aform
from personalityapp.models import amodel
from django.http import FileResponse
def register(request):
    return render(request,'register.html')
def login(request):
    return render(request,'login.html')
def index(request):
    return render(request,'index.html')
def basic(request):
    return render(request,'basic.html')
def education(request):
    return render(request,'education.html')
def employer(request):
    cur=connection.cursor()
    uid=request.session['uid']
    sql="select * from register where uid='%s'"%(uid)
    cur.execute(sql)
    a=[]
    b=cur.fetchall()
    for row in b:
        x={'uid':row[0],'name':row[1],'phn':row[2],'email':row[3]}
        a.append(x)
    return render(request,'employer.html',{'a':a})
def regaction(request):
    cur=connection.cursor()
    nm=request.GET['username']
    ph=request.GET['phno']
    email=request.GET['email']
    upass=request.GET['pwd']
    sql1="insert into register(name,phn,email,pass)values('%s','%s','%s','%s')"%(nm,ph,email,upass)
    cur.execute(sql1)
    sql2="select max(uid)as uid from register"
    cur.execute(sql2)
    rs=cur.fetchall()
    for row in rs:
        sql3="insert into login (uid,uname,upass,utype) value('%s','%s','%s','user')"%(row[0],email,upass)
        cur.execute(sql3)
    msg="<script>alert('successfull');window.location='/index/';</script>"
    return HttpResponse(msg)
def basicaction(request):
    cur=connection.cursor()
    uid=request.session['uid']
    add=request.GET['address']
    dis=request.GET['district']
    pin=request.GET['pincode']
    dob=request.GET['dob']
    gender=request.GET['gender']
    sql1="insert into tbl_basic(address,district,pincode,dob,gender,uid)values('%s','%s','%s','%s','%s','%s')"%(add,dis,pin,dob,gender,uid)
    cur.execute(sql1)
    msg="<script>alert('successfully Submitted');window.location='/userhome/';</script>"
    return HttpResponse(msg)
def eduactionaction(request):
    cur=connection.cursor()
    uid=request.session['uid']
    hq=request.GET['highestqualification']
    mark=request.GET['mark']
    yop=request.GET['yearofpassing']
    univ=request.GET['university']
    exp=request.GET['experience']
    sql1="insert into tbl_education(hqua,mark,year,univ,exp,rid)values('%s','%s','%s','%s','%s','%s')"%(hq,mark,yop,univ,exp,uid)
    cur.execute(sql1)
    msg="<script>alert('Successfully Submitted');window.location='/userhome/';</script>"
    return HttpResponse(msg)
def employeraction(request):
    cur=connection.cursor()
    uid=request.session['uid']
    yops=request.GET['yops']
    cemp=request.GET['cemp']
    emp=request.GET['cnmb']
    eemail=request.GET['email']
    ref=request.GET['ref']
    remail=request.GET['remail']
    ctc=request.GET['ctc']
    sql1="insert into tbl_employer(empyr,emp,ephno,eemail,ref,remail,ctc,rid)values('%s','%s','%s','%s','%s','%s','%s','%s')"%(yops,cemp,emp,eemail,ref,remail,ctc,uid)
    cur.execute(sql1)
    msg="<script>alert('Successfully Added');window.location='/userhome/';</script>"
    return HttpResponse(msg)
def registerview(request):
    cur=connection.cursor()
    sql="select * from register"
    cur.execute(sql)
    a=[]
    b=cur.fetchall()
    for row in b:
        x={'uid':row[0],'name':row[1],'phn':row[2],'email':row[3]}
        a.append(x)
    return render(request,'registerview.html',{'a':a})
def basicview(request):
    cur=connection.cursor()
    sql="select * from tbl_basic"
    cur.execute(sql)
    a=[]
    b=cur.fetchall()
    for row in b:
        x={'bid':row[0],'rid':row[1],'address':row[2],'district':row[3],'pincode':row[4],'dob':row[5],'gender':row[6]}
        a.append(x)
    return render(request,'basicview.html',{'a':a})
def educationview(request):
    cur=connection.cursor()
    sql="select * from tbl_education"
    cur.execute(sql)
    a=[]
    b=cur.fetchall()
    for row in b:
        x={'edid':row[0],'hqua':row[1],'mark':row[2],'year':row[3],'univ':row[4],'exp':row[5],'rid':row[6]}
        a.append(x)
    return render(request,'educationview.html',{'a':a})
def employerview(request):
    cur=connection.cursor()
    sql="select * from tbl_employer"
    cur.execute(sql)
    a=[]
    b=cur.fetchall()
    for row in b:
        x={'empid':row[0],'empyr':row[1],'emp':row[2],'ephno':row[3],'eemail':row[4],'ref':row[5],'remail':row[6],'ctc':row[7],'rid':row[8]}
        a.append(x)
        return render(request,'employerview.html',{'a':a})
def action_page(request):
    cur=connection.cursor()
    uname=request.GET['uname']
    upass=request.GET['psw']
    sql="select * from login where uname='%s' and upass='%s'"%(uname,upass)
    cur.execute(sql)
    if(cur.rowcount)>0:
        a=cur.fetchall()
        for row in a:
            request.session['uid']=row[1]
            request.session['utype']=row[4]
            if(request.session['utype']=='admin'):
                return render(request,'adminhome.html')
            elif(request.session['utype']=='user'):
                return render(request,'userhome.html')
            elif(request.session['utype']=='employer'):
                return render(request,'employerhome.html')
    else:
        msg="<script>alert('invalid username or password');window.location='/index/';</script>"
        return HttpResponse(msg)
def userhome(request):
    return render(request,'userhome.html')
def adminhome(request):
    return render(request,'adminhome.html')
def employerhome(request):
    return render(request,'employerhome.html')
def regdel(request):
    cur=connection.cursor()
    id=request.GET['id']
    sql="delete from register where uid='%s'"%(id)
    cur.execute(sql)
    sq="delete from login where uid='%s'"%(id)
    cur.execute(sq)
    msg="<script>alert('Successfully Deleted');window.location='/registerview/';</script>"
    return HttpResponse(msg)
def basicdel(request):
    cur=connection.cursor()
    id=request.GET['id']
    sql="delete from tbl_basic where bid='%s'"%(id)
    cur.execute(sql)
    msg="<script>alert('Successfully Deleted');window.location='/viewbasic/';</script>"
    return HttpResponse(msg)
def educationdel(request):
    cur=connection.cursor()
    id=request.GET['id']
    sql="delete from tbl_education where edid='%s'"%(id)
    cur.execute(sql)
    msg="<script>alert('Successfully Deleted');window.location='/viewedu/';</script>"
    return HttpResponse(msg)
def employerdel(request):
    cur=connection.cursor()
    id=request.GET['id']
    sql="delete from tbl_employer where empid='%s'"%(id)
    cur.execute(sql)
    msg="<script>alert('Successfully Deleted');window.location='/viewemp/';</script>"
    return HttpResponse(msg)
def regup(request):
    cur=connection.cursor()
    id=request.GET['id']
    sql="select * from register where uid='%s'"%(id)
    cur.execute(sql)
    a=[]
    b=cur.fetchall()
    for row in b:
        x={'uid':row[0],'name':row[1],'phn':row[2],'email':row[3]}
        a.append(x)
    return render(request,'regup.html',{'a':a})
def regupaction(request):
    cur=connection.cursor()
    id=request.GET['id']
    e=request.GET['email']
    p=request.GET['phno']
    sql="update register set email='%s',phn='%s' where uid='%s'"%(e,p,id)
    cur.execute(sql)
    return render(request,'registerview.html')
def basicup(request):
    cur=connection.cursor()
    id=request.GET['id']
    sql="select * from tbl_basic where bid='%s'"%(id)
    cur.execute(sql)
    a=[]
    b=cur.fetchall()
    for row in b:
        x={'bid':row[0],'address':row[1],'district':row[2],'pincode':row[3],'dob':row[4],'gender':row[5],'uid':row[6]}
        a.append(x)
    return render(request,'basicup.html',{'a':a})
def basicupaction(request):
    cur=connection.cursor()
    id=request.GET['id']
    a=request.GET['address']
    d=request.GET['district']
    b=request.GET['dob']
    p=request.GET['pincode']
    sql="update tbl_basic set address='%s',district='%s',pincode='%s' where bid='%s'"%(a,d,p,id)
    cur.execute(sql)
    msg="<script>alert('Successfully Edited');window.location='/viewbasic/';</script>"
    return HttpResponse(msg)
def educationup(request):
    cur=connection.cursor()
    id=request.GET['id']
    sql="select * from tbl_education where edid='%s'"%(id)
    cur.execute(sql)
    a=[]
    b=cur.fetchall()
    for row in b:
        x={'edid':row[0],'hqua':row[1],'mark':row[2],'year':row[3],'univ':row[4],'exp':row[5],'rid':row[6]}
        a.append(x)
    return render(request,'educationup.html',{'a':a})
def eduactionupaction(request):
    cur=connection.cursor()
    id=request.GET['id']
    h=request.GET['highestqualification']
    m=request.GET['mark']
    y=request.GET['yearofpassing']
    u=request.GET['university']
    e=request.GET['experience']
    sql="update tbl_education set hqua='%s',mark='%s',year='%s',univ='%s',exp='%s' where edid='%s'"%(h,m,y,u,e,id)
    cur.execute(sql)
    msg="<script>alert('Successfully Edited');window.location='/viewedu/';</script>"
    return HttpResponse(msg)
def employerup(request):
    cur=connection.cursor()
    id=request.GET['id']
    sql="select * from tbl_employer where empid='%s'"%(id)
    cur.execute(sql)
    a=[]
    b=cur.fetchall()
    for row in b:
        x={'empid':row[0],'empyr':row[1],'emp':row[2],'ephno':row[3],'eemail':row[4],'ref':row[5],'remail':row[6],'ctc':row[7],'rid':row[8]}
        a.append(x)
    return render(request,'employerup.html',{'a':a})
def employerupaction(request):
    cur=connection.cursor()
    id=request.GET['id']
    e=request.GET['yops']
    x=request.GET['cemp']
    p=request.GET['cnmb']
    u=request.GET['email']
    r=request.GET['ref']
    y=request.GET['remail']
    c=request.GET['ctc']
    sql="update tbl_employer set empyr='%s',emp='%s',ephno='%s',eemail='%s',ref='%s',remail='%s',ctc='%s'  where empid='%s'"%(e,x,p,u,r,y,c,id)
    cur.execute(sql)
    msg="<script>alert('Successfully Edited');window.location='/viewemp/';</script>"
    return HttpResponse(msg)
def cvupload(request):
    cur=connection.cursor()
    uid=request.session['uid']
    print(uid)
    return render(request,'cvupload.html',{'uid':uid}) 
def cvuploadaction(request):
    if request.method == "POST":
        Proform = pform(request.POST,request.FILES)
        if Proform.is_valid():
            profile =promodel()
            profile.p_image=Proform.cleaned_data["p_image"]
            profile.uid=request.POST["uid"]
            profile.save()   
            html="<script>alert('Successfully added');window.location='/userhome/';</script>"
            saved = True
    else:
        Proform = pform()
    return HttpResponse(html) 
def job(request):
    return render(request,'job.html') 
def jobaction(request):
    cur=connection.cursor()
    j=request.GET['jobname']
    d=request.GET['dec']
    l=request.GET['lds']
    s=request.GET['sp']
    e=request.GET['eq']
    dt=date.today()
    sql="insert into job(jbname,jbdec,lds,salary,edc,pdte) values('%s','%s','%s','%s','%s','%s')"%(j,d,l,s,e,dt)
    cur.execute(sql)
    return render(request,'job.html')
def jobview(request):
    cur=connection.cursor()
    sql="select * from job"
    cur.execute(sql)
    a=[]
    b=cur.fetchall()
    for row in b:
        x={'jid':row[0],'jbname':row[1],'jbdec':row[2],'lds':row[3],'salary':row[4],'edc':row[5]}
        a.append(x)
        return render(request,'jobview.html',{'a':a})
def questions(request):
    return render(request,'questions.html')
def sample(request):
    return render(request,'sample.html')
def viewjob(request):
    cur=connection.cursor()
    sql="select * from job"
    cur.execute(sql)
    cr=[]
    rs=cur.fetchall()
    for row in rs:
        x={'jid':row[0],'jbname':row[1],'jbdec':row[2],'lds':row[3],'salary':row[4],'edc':row[5],'pdte':row[6]}
        cr.append(x)
    return render(request,'viewjob.html',{'cr':cr})
def jdel(request):
    cur=connection.cursor()
    id=request.GET['id']
    sql="delete from job where jid='%s'"%(id)
    cur.execute(sql)
    msg="<script>alert('Successfully Deleted');window.location='/viewjob/';</script>"
    return HttpResponse(msg)
def jedit(request):
    cur=connection.cursor()
    id=request.GET['id']
    sql="select * from job where jid='%s'"%(id)
    cur.execute(sql)
    cr=[]
    rs=cur.fetchall()
    for row in rs:
        x={'jid':row[0],'jbname':row[1],'jbdec':row[2],'lds':row[3],'salary':row[4],'edc':row[5],'pdte':row[6]}
        cr.append(x)
    return render(request,'jedit.html',{'cr':cr})
def jobupaction(request):
    cur=connection.cursor()
    id=request.GET['id']
    e=request.GET['t2']
    s=request.GET['t3']
    jd=request.GET['t4']
    d=request.GET['t5']
    sql="update job set edc='%s',salary='%s',jbdec='%s',lds='%s' where jid='%s'"%(e,s,jd,d,id)
    cur.execute(sql)
    msg="<script>alert('Successfully Updated');window.location='/viewjob/';</script>"
    return HttpResponse(msg)
def viewbasic(request):
    cur=connection.cursor()
    uid=request.session['uid']
    sql="select * from tbl_basic where uid='%s'"%(uid)
    cur.execute(sql)
    a=[]
    b=cur.fetchall()
    for row in b:
        x={'bid':row[0],'address':row[1],'district':row[2],'pincode':row[3],'dob':row[4],'gender':row[5],'uid':row[6]}
        a.append(x)
    return render(request,'viewbasic.html',{'a':a})
def viewedu(request):
    cur=connection.cursor()
    uid=request.session['uid']
    sql="select * from tbl_education where rid='%s'"%(uid)
    cur.execute(sql)
    a=[]
    b=cur.fetchall()
    for row in b:
        x={'edid':row[0],'hqua':row[1],'mark':row[2],'year':row[3],'univ':row[4],'exp':row[5],'rid':row[6]}
        a.append(x)
    return render(request,'viewedu.html',{'a':a})
def viewemp(request):
    cur=connection.cursor()
    uid=request.session['uid']
    sql="select * from tbl_employer where rid='%s'"%(uid)
    cur.execute(sql)
    a=[]
    b=cur.fetchall()
    for row in b:
        x={'empid':row[0],'empyr':row[1],'emp':row[2],'ephno':row[3],'eemail':row[4],'ref':row[5],'remail':row[6],'ctc':row[7],'rid':row[8]}
        a.append(x)
    return render(request,'viewemp.html',{'a':a})
def apply(request):
    cur=connection.cursor()
    uid=request.session['uid']
    id=request.GET['id']
    sql="select * from job where jid='%s'"%(id)
    cur.execute(sql)
    a=[]
    b=cur.fetchall()
    for row in b:
        x={'jid':row[0],'jbname':row[1],'jbdec':row[2],'lds':row[3],'salary':row[4],'edc':row[5]}
        a.append(x)
    sq="select * from register where uid='%s'"%(uid)
    cur.execute(sq)
    cr=[]
    rs=cur.fetchall()
    for rw in rs:
        y={'uid':rw[0],'name':rw[1],'phn':rw[2],'email':rw[3]}
        cr.append(y)
    return render(request,'apply.html',{'a':a,'cr':cr})
def aplyaction(request):
    if request.method == "POST":
        Proform = aform(request.POST,request.FILES)
        if Proform.is_valid():
            profile =amodel()
            profile.uid=Proform.cleaned_data["uid"]
            profile.name=request.POST["name"]
            profile.email=request.POST["email"]
            profile.jid=request.POST["jid"]
            profile.jname=request.POST["jname"]
            profile.p_image=Proform.cleaned_data["p_image"]
            
            profile.save()   
            html="<script>alert('Successfully added');window.location='/userhome/';</script>"
            saved = True
    else:
        Proform = aform()
    return HttpResponse(html) 
def applyview(request):
    cur=connection.cursor()
    
    sql="select * from tbl_apply"
    cur.execute(sql)
    cr=[]
    rs=cur.fetchall()
    for row in rs:
        x={'aid':row[0],'uid':row[1],'name':row[2],'email':row[3],'jid':row[4],'jname':row[5],'p_image':row[6]}
        cr.append(x)
    sql1="select * from bigfive"
    cur.execute(sql1)
    bf=[]
    rs1=cur.fetchall()
    for row1 in rs1:
        x={'uid':row1[0],'O':row1[1],'C':row1[2],'E':row1[3],'A':row1[4],'N':row1[5]}
        bf.append(x)
        print(row1[1])
    return render(request,'applyview.html',{'cr':cr,'bf':bf})
def questionaction(request):
    cur=connection.cursor()
    uid=request.session['uid']
    E=20+(int)(request.GET['q1'])-(int)(request.GET['q6'])+(int)(request.GET['q11'])-(int)(request.GET['q16'])+(int)(request.GET['q21'])-(int)(request.GET['q26'])+(int)(request.GET['q31'])-(int)(request.GET['q36'])+(int)(request.GET['q41'])-(int)(request.GET['q46'])
    A=14-(int)(request.GET['q2'])+(int)(request.GET['q7'])-(int)(request.GET['q12'])+(int)(request.GET['q17'])-(int)(request.GET['q22'])+(int)(request.GET['q27'])-(int)(request.GET['q32'])+(int)(request.GET['q37'])+(int)(request.GET['q42'])+(int)(request.GET['q47'])
    C=14+(int)(request.GET['q3'])-(int)(request.GET['q8'])+(int)(request.GET['q13'])-(int)(request.GET['q18'])+(int)(request.GET['q23'])-(int)(request.GET['q28'])+(int)(request.GET['q33'])-(int)(request.GET['q38'])+(int)(request.GET['q43'])+(int)(request.GET['q48'])
    N=38-(int)(request.GET['q4'])+(int)(request.GET['q9'])-(int)(request.GET['q14'])+(int)(request.GET['q19'])-(int)(request.GET['q24'])-(int)(request.GET['q29'])-(int)(request.GET['q34'])-(int)(request.GET['q39'])-(int)(request.GET['q44'])-(int)(request.GET['q49'])
    O=8+(int)(request.GET['q5'])-(int)(request.GET['q10'])+(int)(request.GET['q15'])-(int)(request.GET['q20'])+(int)(request.GET['q25'])-(int)(request.GET['q30'])+(int)(request.GET['q35'])+(int)(request.GET['q40'])+(int)(request.GET['q45'])+(int)(request.GET['q50'])
    print(A)
    print(C)
    print(E)
    print(N)
    print(O)
    
    cur.execute("insert into bigfive (uid,O,C,E,A,N) values('%s','%s','%s','%s','%s','%s')"%(uid,O,C,E,A,N))
    return render(request,'questions.html',{'E':E,'C':C,'A':A,'N':N,'O':O})

def cvanalyse(request):
    if request.method == 'POST':
        #Resume.objects.all().delete()
        file_form = UploadResumeModelForm(request.POST, request.FILES)
        files = request.FILES.getlist('resume')
        resumes_data = []
        if file_form.is_valid():
            for file in files:
                try:
                    # saving the file
                    resume = Resume(resume=file)
                    resume.save()
                    
                    # extracting resume entities
                    parser = ResumeParser(os.path.join(settings.MEDIA_ROOT, resume.resume.name))
                    data = parser.get_extracted_data()
                    resumes_data.append(data)
                    resume.name               = data.get('name')
                    resume.email              = data.get('email')
                    resume.mobile_number      = data.get('mobile_number')
                    if data.get('degree') is not None:
                        resume.education      = ', '.join(data.get('degree'))
                    else:
                        resume.education      = None
                    resume.company_names      = data.get('company_names')
                    resume.college_name       = data.get('college_name')
                    resume.designation        = data.get('designation')
                    resume.total_experience   = data.get('total_experience')
                    if data.get('skills') is not None:
                        resume.skills         = ', '.join(data.get('skills'))
                    else:
                        resume.skills         = None
                    if data.get('experience') is not None:
                        resume.experience     = ', '.join(data.get('experience'))
                    else:
                        resume.experience     = None
                    resume.save()
                except IntegrityError:
                    messages.warning(request, 'Duplicate resume found:', file.name)
                    return redirect('homepage')
            resumes = Resume.objects.all()
            messages.success(request, 'Resumes uploaded!')
            context = {
                'resumes': resumes,
            }
            return render(request, 'base.html', context)
    else:
        form = UploadResumeModelForm()
    return render(request, 'base.html', {'form': form})
   